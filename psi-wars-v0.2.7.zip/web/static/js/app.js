/* =============================================================================
   Psi-Wars Combat Simulator — Main App v0.2.7
   ============================================================================= */

import { MOCK_SHIPS, MOCK_ENGAGEMENTS, MOCK_COMBAT_LOG, MOCK_DICE_LOG, MOCK_ACTIVE_STATE } from './mock-data.js?v=0.2.7';
import { renderShipStrip } from './components/ship-card.js?v=0.2.7';
import { createCombatLog, loadMockLog } from './components/combat-log.js?v=0.2.7';
import { createGMPanel } from './components/gm-panel.js?v=0.2.7';
import { createEngagementDisplay } from './components/engagement-display.js?v=0.2.7';

document.addEventListener('DOMContentLoaded', () => {
  const shipStrip = document.getElementById('ship-strip');
  const engStrip = document.getElementById('engagement-strip');
  const turnDisplay = document.getElementById('turn-display');
  const logContainer = document.getElementById('combat-log');
  const gmContainer = document.getElementById('gm-panel');

  turnDisplay.textContent = `Turn ${MOCK_ACTIVE_STATE.current_turn}`;

  const combatLog = createCombatLog(logContainer);
  loadMockLog(combatLog, MOCK_COMBAT_LOG);

  const gmPanel = createGMPanel(gmContainer, {
    onUndo: () => combatLog.addEntry('[GM] Undo requested', 'info'),
    onRedo: () => combatLog.addEntry('[GM] Redo requested', 'info'),
  });
  gmPanel.loadDiceLog(MOCK_DICE_LOG);

  const engDisplay = createEngagementDisplay(engStrip);

  function setShipField(ship, field, value) {
    const parts = field.split('.');
    if (parts.length === 2) ship[parts[0]][parts[1]] = value;
    else if (field === 'ht') ship[field] = String(value);
    else ship[field] = value;
  }

  function updateWoundLevel(ship) {
    const pct = ship.st_hp > 0 ? ship.current_hp / ship.st_hp : 0;
    if (ship.current_hp <= 0) { ship.wound_level = 'destroyed'; ship.is_destroyed = true; }
    else if (pct <= 0.33) { ship.wound_level = 'crippling'; ship.is_destroyed = false; }
    else if (pct <= 0.66) { ship.wound_level = 'major'; ship.is_destroyed = false; }
    else { ship.wound_level = 'minor'; ship.is_destroyed = false; }
  }

  const cardCallbacks = {
    gmMode: true,
    onSubsystemChange: (shipId, sys, newStatus) => {
      const ship = MOCK_SHIPS.find(s => s.ship_id === shipId);
      if (!ship) return;
      ship.disabled_systems = ship.disabled_systems.filter(s => s !== sys);
      ship.destroyed_systems = ship.destroyed_systems.filter(s => s !== sys);
      if (newStatus === 'disabled') ship.disabled_systems.push(sys);
      if (newStatus === 'destroyed') ship.destroyed_systems.push(sys);
      refreshShips();
    },
    onFieldChange: (shipId, field, newValue) => {
      const ship = MOCK_SHIPS.find(s => s.ship_id === shipId);
      if (!ship) return;
      setShipField(ship, field, newValue);
      if (field === 'current_hp' || field === 'st_hp') updateWoundLevel(ship);
      refreshShips();
    }
  };

  function refreshShips() {
    cardCallbacks.gmMode = true;
    renderShipStrip(shipStrip, MOCK_SHIPS, MOCK_ACTIVE_STATE, cardCallbacks);
    engDisplay.render(MOCK_ENGAGEMENTS, MOCK_SHIPS);
  }

  refreshShips();

  const gmToggle = document.getElementById('gm-toggle');
  gmToggle.addEventListener('click', () => {
    const app = document.getElementById('app');
    app.classList.toggle('gm-hidden');
    gmToggle.classList.toggle('active');
    gmToggle.textContent = app.classList.contains('gm-hidden') ? 'Show GM' : 'Hide GM';
  });
  gmToggle.classList.add('active');
  gmToggle.textContent = 'Hide GM';
});
