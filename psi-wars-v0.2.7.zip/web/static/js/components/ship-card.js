/* =============================================================================
   Ship Card Component v0.2.7
   Fixes:
   - Expanded details now actually visible
   - Stat labels have title tooltips
   - Compact logic: only active/target get full cards, everyone else compact
   - Source page link works
   ============================================================================= */

const SUBSYSTEMS = ['propulsion', 'weapons', 'sensors', 'reactor', 'comms', 'life_support'];
const SUBSYSTEM_LABELS = {
  propulsion: 'PROP', weapons: 'WEAP', sensors: 'SENS',
  reactor: 'RCTR', comms: 'COMM', life_support: 'LIFE'
};
const STAT_TOOLTIPS = {
  HND: 'Handling', SR: 'Stability Rating', 'DR/F': 'Damage Resistance (Front)',
  SPD: 'Top Speed', HT: 'Health', ECM: 'Electronic Counter-Measures'
};

function hpPercent(ship) { return Math.max(0, Math.min(100, (ship.current_hp / ship.st_hp) * 100)); }
function hpClass(pct) {
  if (pct > 80) return 'hp-full'; if (pct > 60) return 'hp-high';
  if (pct > 35) return 'hp-medium'; if (pct > 15) return 'hp-low'; return 'hp-critical';
}
function fdrPercent(ship) {
  if (!ship.fdr_max || ship.fdr_max === 0) return 0;
  return Math.max(0, Math.min(100, (ship.current_fdr / ship.fdr_max) * 100));
}
function subsystemStatus(ship, sys) {
  if (ship.destroyed_systems.includes(sys)) return 'destroyed';
  if (ship.disabled_systems.includes(sys)) return 'disabled';
  return 'ok';
}
function factionColor(faction) {
  return { Empire: '#e05454', Alliance: '#3fb5e5', Trader: '#3fb950', Pirate: '#d4a843' }[faction] || '#6e7681';
}
function dotStyle(status) {
  const c = status === 'ok' ? 'var(--success)' : status === 'disabled' ? 'var(--warn)' : 'var(--danger)';
  return `background:${c};box-shadow:0 0 4px ${c};`;
}
function buildSubsystemDotsHTML(ship) {
  return SUBSYSTEMS.map(sys => {
    const status = subsystemStatus(ship, sys);
    return `<div class="subsystem-dot-row" data-subsystem="${sys}" data-status="${status}" title="${sys}: ${status}">
      <span class="subsystem-dot" style="${dotStyle(status)}"></span>
      <span class="subsystem-dot-label">${SUBSYSTEM_LABELS[sys]}</span>
    </div>`;
  }).join('');
}

function editableVal(field, value, gmMode) {
  if (!gmMode) return String(value);
  return `<span class="editable-stat" data-field="${field}" title="Click to edit">${value}</span>`;
}

function attachEditableStats(container, onChange) {
  container.querySelectorAll('.editable-stat').forEach(el => {
    el.addEventListener('click', (e) => {
      e.stopPropagation();
      if (el.querySelector('input')) return;
      const field = el.dataset.field;
      const currentVal = el.textContent.trim();
      const width = Math.max(3, currentVal.length + 1);
      const input = document.createElement('input');
      input.type = 'number';
      input.className = 'editable-stat-input';
      input.value = currentVal;
      input.style.width = width + 'ch';
      el.textContent = '';
      el.appendChild(input);
      input.focus();
      input.select();
      function commit() {
        const newVal = parseInt(input.value);
        if (!isNaN(newVal)) onChange(field, newVal);
      }
      input.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); commit(); }
        if (ev.key === 'Escape') { el.textContent = currentVal; }
        ev.stopPropagation();
      });
      input.addEventListener('blur', commit);
      input.addEventListener('click', (ev) => ev.stopPropagation());
    });
  });
}

function attachSubsystemCycling(card, callbacks) {
  card.querySelectorAll('.subsystem-dot-row').forEach(row => {
    row.addEventListener('click', (e) => {
      e.stopPropagation();
      const sys = row.dataset.subsystem;
      const cur = row.dataset.status;
      const next = cur === 'ok' ? 'disabled' : cur === 'disabled' ? 'destroyed' : 'ok';
      if (callbacks.onSubsystemChange) {
        callbacks.onSubsystemChange(row.closest('.ship-card').dataset.shipId, sys, next);
      }
    });
  });
}

function statCell(label, tooltip, field, value, gm) {
  return `<div class="stat" title="${tooltip}"><div class="stat-label">${label}</div><div class="stat-value">${editableVal(field, value, gm)}</div></div>`;
}

function renderCard(card, ship, highlight, isCompact, callbacks) {
  const hp = hpPercent(ship);
  const fdr = fdrPercent(ship);
  const gm = !!callbacks.gmMode;
  const ev = (field, val) => editableVal(field, val, gm);

  if (isCompact) {
    card.innerHTML = `
      <div class="card-header">
        <div class="card-name">${ship.display_name}</div>
        <div class="card-class">${ship.ship_class}</div>
      </div>
      <div class="hp-bar-container">
        <div class="hp-bar-label"><span>HP</span><span>${ev('current_hp', ship.current_hp)}/${ship.st_hp}</span></div>
        <div class="hp-bar"><div class="hp-bar-fill ${hpClass(hp)}" style="width:${hp}%"></div></div>
      </div>
      <div class="subsystem-dots">${buildSubsystemDotsHTML(ship)}</div>
    `;
  } else {
    const templateName = ship.template_id.replace(/_/g, ' ').replace(/v\d+$/, '').trim();
    const sourceLink = ship.source_url
      ? `<a class="card-source-link" href="${ship.source_url}" target="_blank" title="Open ${templateName} source page">→ ${templateName} Source Page</a>`
      : '';

    card.innerHTML = `
      <div class="card-header">
        <div>
          <div class="card-name">${ship.display_name}</div>
          <div class="card-template">${templateName}</div>
        </div>
        <div class="card-class">${ship.ship_class} SM${ship.sm}</div>
      </div>
      <div class="card-faction" style="color:${factionColor(ship.faction)}">${ship.faction} · ${ship.control}</div>
      <div class="hp-bar-container">
        <div class="hp-bar-label"><span>HP</span><span>${ev('current_hp', ship.current_hp)} / ${ev('st_hp', ship.st_hp)}</span></div>
        <div class="hp-bar"><div class="hp-bar-fill ${hpClass(hp)}" style="width:${hp}%"></div></div>
      </div>
      ${ship.fdr_max > 0 ? `
      <div class="hp-bar-container fdr-bar-container">
        <div class="hp-bar-label"><span>fDR${ship.force_screen_type !== 'none' ? ' (' + ship.force_screen_type + ')' : ''}</span><span>${ev('current_fdr', ship.current_fdr)} / ${ev('fdr_max', ship.fdr_max)}</span></div>
        <div class="hp-bar"><div class="fdr-bar-fill" style="width:${fdr}%"></div></div>
      </div>
      ` : ''}
      <div class="card-stats">
        ${statCell('HND', 'Handling', 'hnd', ship.hnd, gm)}
        ${statCell('SR', 'Stability Rating', 'sr', ship.sr, gm)}
        ${statCell('DR/F', 'Damage Resistance (Front)', 'dr_front', ship.dr_front, gm)}
        ${statCell('SPD', 'Top Speed', 'top_speed', ship.top_speed, gm)}
        ${statCell('HT', 'Health', 'ht', parseInt(ship.ht) || 0, gm)}
        ${statCell('ECM', 'Electronic Counter-Measures', 'ecm_rating', ship.ecm_rating, gm)}
      </div>
      <div class="card-weapons">
        ${ship.weapons.map(w => `
          <div class="weapon-row">
            <span class="weapon-name" title="${w.name}">${w.name.length > 24 ? w.name.substring(0, 22) + '…' : w.name}</span>
            <span class="weapon-dmg" title="${w.damage_str}">${w.damage_str.length > 20 ? w.damage_str.substring(0, 18) + '…' : w.damage_str}</span>
          </div>
        `).join('')}
      </div>
      <div class="subsystem-dots">${buildSubsystemDotsHTML(ship)}</div>
      <div class="pilot-row">
        <span class="pilot-name">${ship.pilot.name}</span>
        <span class="pilot-skill">P${ev('pilot.piloting_skill', ship.pilot.piloting_skill)} G${ev('pilot.gunnery_skill', ship.pilot.gunnery_skill)}</span>
      </div>

      <div class="card-expanded-details">
        <div class="detail-section-title">Armor (DR by facing)</div>
        <div class="detail-grid">
          <dt>Front</dt><dd>${ev('dr_front', ship.dr_front)}</dd>
          <dt>Rear</dt><dd>${ev('dr_rear', ship.dr_rear)}</dd>
          <dt>Left</dt><dd>${ev('dr_left', ship.dr_left)}</dd>
          <dt>Right</dt><dd>${ev('dr_right', ship.dr_right)}</dd>
          <dt>Top</dt><dd>${ev('dr_top', ship.dr_top)}</dd>
          <dt>Bottom</dt><dd>${ev('dr_bottom', ship.dr_bottom)}</dd>
        </div>

        <div class="detail-section-title">Performance</div>
        <div class="detail-grid">
          <dt>Acceleration</dt><dd>${ev('accel', ship.accel)}</dd>
          <dt>Top Speed</dt><dd>${ev('top_speed', ship.top_speed)}</dd>
          <dt>Stall Speed</dt><dd>${ev('stall_speed', ship.stall_speed)}</dd>
          <dt>Handling/SR</dt><dd>${ev('hnd', ship.hnd)}/${ev('sr', ship.sr)}</dd>
        </div>

        <div class="detail-section-title">Electronics</div>
        <div class="detail-grid">
          <dt>ECM Rating</dt><dd>${ev('ecm_rating', ship.ecm_rating)}</dd>
          <dt>Targeting Bonus</dt><dd>+${ev('targeting_bonus', ship.targeting_bonus)}</dd>
          <dt>Tactical ESM</dt><dd>${ship.has_tactical_esm ? 'Yes' : 'No'}</dd>
          <dt>Decoy Launcher</dt><dd>${ship.has_decoy_launcher ? 'Yes' : 'No'}</dd>
        </div>

        <div class="detail-section-title">Pilot</div>
        <div class="detail-grid">
          <dt>Name</dt><dd>${ship.pilot.name}</dd>
          <dt>Piloting Skill</dt><dd>${ev('pilot.piloting_skill', ship.pilot.piloting_skill)}</dd>
          <dt>Gunnery Skill</dt><dd>${ev('pilot.gunnery_skill', ship.pilot.gunnery_skill)}</dd>
          <dt>Basic Speed</dt><dd>${ship.pilot.basic_speed}</dd>
          <dt>Ace Pilot</dt><dd>${ship.pilot.is_ace_pilot ? 'Yes' : 'No'}</dd>
          <dt>Luck</dt><dd>${ship.pilot.luck_level}</dd>
          <dt>Fatigue Points</dt><dd>${ev('pilot.current_fp', ship.pilot.current_fp)}/${ev('pilot.max_fp', ship.pilot.max_fp)}</dd>
          <dt>Emergency Power</dt><dd>${ev('emergency_power_reserves', ship.emergency_power_reserves)}</dd>
        </div>

        <div class="detail-section-title">Weapons (Full Detail)</div>
        ${ship.weapons.map(w => `
          <div class="weapon-detail-block">
            <div class="weapon-detail-name">${w.name}</div>
            <div class="detail-grid">
              <dt>Damage</dt><dd>${w.damage_str}</dd>
              <dt>Accuracy</dt><dd>${w.acc}</dd>
              <dt>Rate of Fire</dt><dd>${w.rof}</dd>
              <dt>Range</dt><dd>${w.range_str}</dd>
              <dt>Mount</dt><dd>${w.mount.replace(/_/g, ' ')}</dd>
              <dt>Armor Divisor</dt><dd>${w.armor_divisor}</dd>
              <dt>Type</dt><dd>${w.weapon_type}</dd>
              <dt>Explosive</dt><dd>${w.is_explosive ? 'Yes' : 'No'}</dd>
            </div>
          </div>
        `).join('')}

        ${sourceLink}
      </div>
    `;
  }

  attachSubsystemCycling(card, callbacks);
  if (gm && callbacks.onFieldChange) {
    attachEditableStats(card, (field, newVal) => {
      callbacks.onFieldChange(ship.ship_id, field, newVal);
    });
  }
}

// --- Public API ---
export function createShipCard(ship, highlight = null, isCompact = false, callbacks = {}) {
  const card = document.createElement('div');
  card.className = 'ship-card';
  card.dataset.shipId = ship.ship_id;
  if (ship.is_destroyed) card.classList.add('destroyed');
  if (highlight === 'active') card.classList.add('active');
  if (highlight === 'target') card.classList.add('target');
  if (highlight === 'targeting') card.classList.add('targeting');
  if (isCompact) card.classList.add('compact');

  renderCard(card, ship, highlight, isCompact, callbacks);

  card.addEventListener('click', (e) => {
    if (e.target.closest('.subsystem-dot-row')) return;
    if (e.target.closest('.editable-stat')) return;
    if (e.target.closest('.editable-stat-input')) return;
    if (e.target.closest('.card-source-link')) return;
    card.classList.toggle('expanded');
  });

  return card;
}

export function renderShipStrip(containerEl, ships, activeState, callbacks = {}) {
  containerEl.innerHTML = '';
  // Only active ship and its direct targets get full cards
  const fullIds = new Set();
  if (activeState.active_ship_id) fullIds.add(activeState.active_ship_id);
  activeState.targets.forEach(id => fullIds.add(id));

  ships.forEach(ship => {
    let highlight = null;
    if (ship.ship_id === activeState.active_ship_id) highlight = 'active';
    else if (activeState.targets.includes(ship.ship_id)) highlight = 'target';
    else if (activeState.targeting.includes(ship.ship_id)) highlight = 'targeting';

    const isCompact = !fullIds.has(ship.ship_id);
    const card = createShipCard(ship, highlight, isCompact, callbacks);
    containerEl.appendChild(card);
  });

  const activeCard = containerEl.querySelector('.ship-card.active');
  if (activeCard) activeCard.scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
}
