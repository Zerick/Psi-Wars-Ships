/* =============================================================================
   Engagement Display Component v0.2.7
   - Range and advantage stacked vertically in center
   - Faction shown on hover over ship names
   - Matched speed / hugging as tags
   ============================================================================= */

const RANGE_COLORS = {
  close: 'var(--danger)', medium: 'var(--warn)',
  long: 'var(--accent)', extreme: 'var(--text-dim)'
};
const RANGE_LABELS = {
  close: 'CLOSE', medium: 'MED', long: 'LONG', extreme: 'EXT'
};

function getShip(ships, id) { return ships.find(s => s.ship_id === id); }

function factionColorFor(ships, id) {
  const ship = getShip(ships, id);
  if (!ship) return 'var(--text-dim)';
  return { Empire: '#e05454', Alliance: '#3fb5e5', Trader: '#3fb950', Pirate: '#d4a843' }[ship.faction] || 'var(--text-dim)';
}

export function createEngagementDisplay(containerEl) {
  function render(engagements, ships) {
    if (!engagements || engagements.length === 0) {
      containerEl.innerHTML = `<div class="engagement-empty">No active engagements</div>`;
      return;
    }

    containerEl.innerHTML = engagements.map(eng => {
      const shipA = getShip(ships, eng.ship_a_id);
      const shipB = getShip(ships, eng.ship_b_id);
      const nameA = shipA ? shipA.display_name : eng.ship_a_id;
      const nameB = shipB ? shipB.display_name : eng.ship_b_id;
      const factionA = shipA ? shipA.faction : '';
      const factionB = shipB ? shipB.faction : '';
      const colorA = factionColorFor(ships, eng.ship_a_id);
      const colorB = factionColorFor(ships, eng.ship_b_id);
      const rangeColor = RANGE_COLORS[eng.range_band] || 'var(--text-dim)';
      const rangeLabel = RANGE_LABELS[eng.range_band] || eng.range_band.toUpperCase();

      // Advantage text
      let advText = 'NO ADV';
      let advClass = 'eng-no-advantage';
      if (eng.advantage === eng.ship_a_id) {
        advText = `◀ ${nameA}`;
        advClass = 'eng-advantage';
      } else if (eng.advantage === eng.ship_b_id) {
        advText = `${nameB} ▶`;
        advClass = 'eng-advantage';
      }

      // Tags
      let tags = [];
      if (eng.matched_speed) tags.push('<span class="eng-tag eng-matched">MATCHED SPD</span>');
      if (eng.hugging === eng.ship_a_id) tags.push(`<span class="eng-tag eng-hugging">${nameA} HUGGING</span>`);
      if (eng.hugging === eng.ship_b_id) tags.push(`<span class="eng-tag eng-hugging">${nameB} HUGGING</span>`);

      return `
        <div class="engagement-row">
          <span class="eng-ship" style="color:${colorA}" title="${factionA}">${nameA}</span>
          <span class="eng-center">
            <span class="eng-line" style="border-color:${rangeColor}"></span>
            <span class="eng-center-stack">
              <span class="eng-range" style="color:${rangeColor};border-color:${rangeColor}">${rangeLabel}</span>
              <span class="${advClass}">${advText}</span>
            </span>
            <span class="eng-line" style="border-color:${rangeColor}"></span>
          </span>
          <span class="eng-ship" style="color:${colorB}" title="${factionB}">${nameB}</span>
          ${tags.length ? `<span class="eng-tags">${tags.join('')}</span>` : ''}
        </div>
      `;
    }).join('');
  }

  return { render };
}
