/* =============================================================================
   Combat Log Component v0.2.7
   - Dice results show TOTAL only, breakdown on hover
   - Verbose (v flag) shows full breakdown inline
   - Inline [[expr]] replaced in-place in the text
   - Unknown commands silently ignored
   ============================================================================= */

function formatRollInline(result) {
  // Returns HTML for inline display
  if (result.type === 'help' || result.type === 'about') {
    return { inline: null, block: result.text };
  }
  if (result.type === 'stats') {
    return { inline: null, block: result.text };
  }
  if (result.type === 'error') {
    return { inline: null, block: null }; // silently ignore errors
  }
  if (result.type === 'roll') {
    if (result.verbose) {
      // Verbose: show full breakdown inline
      return {
        inline: `<span class="dice-result-verbose" title="${result.expression}">${result.breakdown}</span>`,
        block: null
      };
    }
    // Normal: total only, breakdown on hover
    return {
      inline: `<span class="dice-result" title="${result.expression}: ${result.breakdown}">${result.total}</span>`,
      block: null
    };
  }
  return { inline: null, block: null };
}

export function createCombatLog(containerEl) {
  containerEl.innerHTML = `
    <div class="log-header">
      <span class="log-header-title">Combat Log</span>
      <span class="log-header-title" id="log-entry-count" style="color: var(--text-muted)">0 entries</span>
    </div>
    <div class="log-body" id="log-body"></div>
    <div class="log-input-area">
      <input type="text" class="log-input" id="log-input"
             placeholder="Type message or [[3d6]] to roll… [[help]] for commands"
             autocomplete="off">
      <button class="log-send-btn" id="log-send">Send</button>
    </div>
  `;

  const logBody = containerEl.querySelector('#log-body');
  const logInput = containerEl.querySelector('#log-input');
  const logSend = containerEl.querySelector('#log-send');
  const logCount = containerEl.querySelector('#log-entry-count');
  let entryCount = 0;

  function addEntry(message, eventType = 'info', turn = null) {
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.dataset.type = eventType;
    if (turn !== null) entry.dataset.turn = turn;
    entry.textContent = message;
    logBody.appendChild(entry);
    entryCount++;
    logCount.textContent = `${entryCount} entries`;
    logBody.scrollTop = logBody.scrollHeight;
    return entry;
  }

  function addHTMLEntry(html, eventType = 'info', turn = null) {
    const entry = document.createElement('div');
    entry.className = 'log-entry';
    entry.dataset.type = eventType;
    if (turn !== null) entry.dataset.turn = turn;
    entry.innerHTML = html;
    logBody.appendChild(entry);
    entryCount++;
    logCount.textContent = `${entryCount} entries`;
    logBody.scrollTop = logBody.scrollHeight;
    return entry;
  }

  async function rollExpression(expr) {
    const resp = await fetch('/api/dice/roll', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ expression: expr })
    });
    return await resp.json();
  }

  async function handleInput() {
    const text = logInput.value.trim();
    if (!text) return;
    logInput.value = '';
    logInput.focus();

    const pattern = /\[\[([^\]]+)\]\]/g;
    const matches = [...text.matchAll(pattern)];

    // No dice expressions — plain text
    if (matches.length === 0) {
      addEntry(text, 'info');
      return;
    }

    // Check if entire input is a single command
    const isSingleCommand = matches.length === 1 && text.trim() === `[[${matches[0][1]}]]`;

    if (isSingleCommand) {
      const result = await rollExpression(matches[0][1]).catch(() => ({ type: 'error' }));

      if (result.type === 'help' || result.type === 'about') {
        addEntry(result.text, 'info');
        return;
      }
      if (result.type === 'stats') {
        addEntry(result.text, 'dice');
        return;
      }
      if (result.type === 'roll') {
        const formatted = formatRollInline(result);
        if (formatted.inline) {
          addHTMLEntry(`🎲 ${formatted.inline}`, 'dice');
        }
        return;
      }
      // error or unknown — silently ignore
      return;
    }

    // Mixed text with inline rolls — replace [[expr]] with results in-place
    let outputHTML = escapeHTML(text);
    let hasRolls = false;

    for (const m of matches) {
      const result = await rollExpression(m[1]).catch(() => ({ type: 'error' }));
      const formatted = formatRollInline(result);

      if (formatted.inline) {
        outputHTML = outputHTML.replace(
          escapeHTML(`[[${m[1]}]]`),
          formatted.inline
        );
        hasRolls = true;
      } else if (formatted.block) {
        // Help/about/stats in mixed text — show the text then the block
        outputHTML = outputHTML.replace(escapeHTML(`[[${m[1]}]]`), '');
        // We'll add block content after
      } else {
        // Error/unknown — remove the brackets silently
        outputHTML = outputHTML.replace(escapeHTML(`[[${m[1]}]]`), escapeHTML(`[[${m[1]}]]`));
      }
    }

    addHTMLEntry(outputHTML, hasRolls ? 'dice' : 'info');
  }

  function escapeHTML(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  logSend.addEventListener('click', handleInput);
  logInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') handleInput();
  });

  return {
    addEntry,
    addHTMLEntry,
    clear() { logBody.innerHTML = ''; entryCount = 0; logCount.textContent = '0 entries'; },
    getEntryCount() { return entryCount; },
    scrollToBottom() { logBody.scrollTop = logBody.scrollHeight; },
    scrollToTurn(turn) {
      const entries = logBody.querySelectorAll(`[data-turn="${turn}"][data-type="turn"]`);
      if (entries.length > 0) entries[0].scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };
}

export function loadMockLog(combatLog, entries) {
  entries.forEach(entry => {
    combatLog.addEntry(entry.message, entry.event_type, entry.turn);
  });
}
